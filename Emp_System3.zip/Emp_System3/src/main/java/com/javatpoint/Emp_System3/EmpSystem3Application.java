package com.javatpoint.Emp_System3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpSystem3Application {

	public static void main(String[] args) {
		SpringApplication.run(EmpSystem3Application.class, args);
	}

}
