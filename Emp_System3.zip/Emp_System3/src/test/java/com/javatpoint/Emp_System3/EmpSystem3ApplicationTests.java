package com.javatpoint.Emp_System3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpSystem3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
